# J&L Trucking Apply Page

Upload `index.html` to your GitHub Pages repository.

Optional: put your J&L logo in the same folder and name it `logo.png`.

The three WhatsApp buttons are already configured:
- English: 862-310-8814
- Español: 201-951-7168
- Español: 809-912-7984
